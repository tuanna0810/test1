## 收集各种祝福类炫酷页面
欢迎大家贡献、fork

## 页面来源
1. 大部分应该是来自于github上已经实现的效果，本项目进行聚合和简单加工
2. 其他论坛看到的炫酷动画或者效果
3. 仓库贡献者实现的

**声明**：我会维护一份页面来源表格，大家如果想看源项目地址或者代码可以从表格找到出去

## 资源列表

### GitHub来源

| 项目名称 | 仓库地址 |
|:--: | :-: |
| Happy-birthDay | https://github.com/Junrui-L/Happy-birthDay |
| happybirthday | https://github.com/shibobo/happybirthday |
| canvas- | https://github.com/cunzher/canvas- |
| birthday | https://github.com/wrr502/birthday |



